from __future__ import annotations

import sqlite3
import time
from typing import Any

from .models import clean_text
from .service import MemoryCompanionService


# A10: read-only commands are safe for ordinary group members; everything that
# mutates memory, config or diagnostics stays admin-only.  main.py consumes
# command_permission() instead of hard-coding @permission_type on every entry.
COMMAND_PERMISSION_MEMBER = "member"
COMMAND_PERMISSION_ADMIN = "admin"
READ_ONLY_COMMANDS = frozenset(
    {
        "status",
        "search",
        "explain",
        "recent",
        "timeline",
        "relations",
        "logs",
        "diagnostics",
        "help",
    }
)


def command_permission(name: str) -> str:
    """Return the minimum permission level for one mcomp sub-command."""
    return (
        COMMAND_PERMISSION_MEMBER
        if clean_text(name, 40).strip().lower() in READ_ONLY_COMMANDS
        else COMMAND_PERMISSION_ADMIN
    )


def read_only_commands() -> frozenset[str]:
    """Expose the read-only command set for main.py and the release report."""
    return READ_ONLY_COMMANDS


class MemoryCompanionCommandHandler:
    # A10: destructive commands need an explicit second step.
    DELETE_CONFIRM_TTL_SECONDS = 120
    DELETE_CONFIRM_WORDS = frozenset({"确认", "delete", "yes", "y"})

    def __init__(self, service: MemoryCompanionService, version: str):
        self.service = service
        self.version = version
        self._pending_deletes: dict[str, float] = {}

    async def status(self) -> str:
        stats = await self.service.store.stats()
        sleep = self.service.sleep_status()
        by_scope = ", ".join(f"{key or 'unknown'}={value}" for key, value in stats["by_scope"].items()) or "none"
        return (
            "我会牢牢记住你：运行中\n"
            f"版本：{self.version}\n"
            f"记忆：{stats['total_memories']} 条，稳定 {stats['stable_memories']} 条\n"
            f"身份：{stats['identities']} 个；关系边：{stats['relationships']} 条；自我时间线：{stats['timeline_events']} 条\n"
            f"跨窗口线程：{stats['open_threads']} 条；注入日志：{stats['injection_logs']} 条\n"
            f"睡眠维护：{sleep.get('ran_at') or sleep.get('message') or '-'}\n"
            f"范围：{by_scope}\n"
            f"数据库：{stats['db_path']}"
        )

    async def search(self, event: Any, query: str = "", k: int = 6) -> str:
        if not query.strip():
            return "用法：/mcomp search 关键词"
        results = await self.service.search_for_event(event, query, k)
        if not results:
            return "没有检索到当前会话可见的记忆。"
        lines = [f"检索结果：{len(results)} 条"]
        for item in results:
            memory = item.memory
            lines.append(
                f"- {memory.id}｜{memory.memory_type}｜{memory.visibility}｜{memory.reality_level}｜{memory.content[:180]}｜score={item.score:.2f}｜{item.reason}"
            )
        return "\n".join(lines)

    async def explain(self, event: Any, query: str = "", k: int = 6) -> str:
        if not query.strip():
            return "用法：/mcomp explain 关键词"
        intent, selected, blocked, slot_map = await self.service.explain_context_for_event(event, query, k)
        lines = [
            f"召回解释：选中 {len(selected)} 条，过滤 {len(blocked)} 条",
            f"检索来源：{intent.source}｜检索词：{clean_text(intent.query, 180)}",
        ]
        # R12：诊断入口显式要求遥测（检索模式/关键词/Bot 心理能量），注入路径不输出。
        intent_hint = intent.format_for_injection(320, include_diagnostics=True)
        if intent_hint:
            lines.append("【检索意图】")
            lines.append(intent_hint)
        if selected:
            lines.append("【选中】")
            for slot, items in slot_map.items():
                lines.append(f"[{slot}]")
                for item in items:
                    lines.append(
                        f"- {item.memory.id}｜{item.memory.visibility}｜score={item.score:.2f}｜{item.reason}｜{item.memory.content[:120]}"
                    )
        if blocked:
            lines.append("【过滤示例】")
            for item in blocked[:10]:
                lines.append(f"- {item.get('id')}｜{item.get('reason')}｜{item.get('content')}")
        return "\n".join(lines)

    async def recent(self, limit: int = 10) -> str:
        memories = await self.service.store.recent_memories(limit=limit, include_pending=False)
        if not memories:
            return "还没有记忆。"
        lines = [f"最近记忆：{len(memories)} 条"]
        for memory in memories:
            lines.append(
                f"- {memory.id}｜{memory.scope}｜{memory.visibility}｜{memory.content[:180]}"
            )
        return "\n".join(lines)

    async def add(self, event: Any, content: str = "") -> str:
        content = clean_text(content, 3000)
        if not content:
            return "用法：/mcomp add 要记住的内容"
        memory_id = await self.service.add_manual_memory(event, content)
        return f"记住了：{memory_id}"

    async def summarize(self, event: Any) -> str:
        ctx = await self.service.identity.resolve_event_context(event)
        memory_id = await self.service.maybe_summarize_session(ctx, force=True)
        if not memory_id:
            return "本次未生成新记忆：可能无新增内容、模型暂不可用或批次仍待修复。原文已保留，可在面板总览查看处理进度。"
        return f"已生成阶段性长期记忆：{memory_id}"

    async def delete(self, memory_id: str = "", confirm: str = "") -> str:
        """Delete one memory after an explicit second confirmation (A10).

        The chat channel cannot render a modal, so the first call only arms a
        short-lived pending confirmation for that id and repeats the command
        text; sending the same command again inside the TTL (or passing
        confirm="确认") performs the delete.  This mirrors the two-step
        preview/清空 flow of clear_scope instead of deleting on first touch.
        """
        memory_id = clean_text(memory_id, 120)
        if not memory_id:
            return "用法：/mcomp delete <memory_id>"
        explicit = clean_text(confirm, 20).casefold() in self.DELETE_CONFIRM_WORDS
        if not explicit and not self._consume_delete_confirmation(memory_id):
            self._pending_deletes[memory_id] = (
                time.monotonic() + self.DELETE_CONFIRM_TTL_SECONDS
            )
            return (
                f"将要删除记忆：{memory_id}（不可恢复）。\n"
                f"请在 {self.DELETE_CONFIRM_TTL_SECONDS} 秒内再次执行同一条命令确认，"
                "或使用 /mcomp delete <memory_id> 确认。"
            )
        self._pending_deletes.pop(memory_id, None)
        try:
            ok = await self.service.store.delete_memory(memory_id)
        except sqlite3.OperationalError as exc:
            # Keep the memory instead of implying success: the row is still
            # there and the user needs to know why the write was refused.
            return (
                "删除失败：记忆库暂时无法写入，这条记忆仍然保留。\n"
                f"原因：{clean_text(exc, 400)}\n"
                "可在面板「运维诊断」查看库文件路径与最近一次连接重建失败详情。"
            )
        return "已删除。" if ok else "没有找到这条记忆。"

    def _consume_delete_confirmation(self, memory_id: str) -> bool:
        """Consume a still-valid pending delete confirmation for one id."""
        expires_at = self._pending_deletes.pop(memory_id, None)
        if expires_at is None:
            return False
        return expires_at >= time.monotonic()

    async def clear_scope(
        self,
        target_type: str = "",
        first_id: str = "",
        second_id: str = "",
        confirm: str = "",
    ) -> str:
        target_type = clean_text(target_type, 40).lower()
        first_id = clean_text(first_id, 120)
        second_id = clean_text(second_id, 120)
        confirm = clean_text(confirm, 20)
        if target_type in {"group", "private"} and second_id == "清空" and not confirm:
            confirm = second_id
            second_id = ""
        if target_type not in {"group", "private", "group_member"}:
            return (
                "用法：\n"
                "/mcomp clear_scope group <群号> [清空]\n"
                "/mcomp clear_scope private <QQ> [清空]\n"
                "/mcomp clear_scope group_member <群号> <QQ> [清空]\n"
                "不带“清空”只预览数量，带“清空”才执行。"
            )
        group_id = first_id if target_type in {"group", "group_member"} else ""
        user_id = first_id if target_type == "private" else second_id
        try:
            if confirm == "清空":
                result = await self.service.clear_scoped_memory(
                    target_type=target_type,
                    group_id=group_id,
                    user_id=user_id,
                )
                action = "已清空"
            else:
                result = await self.service.store.preview_scoped_memory_clear(
                    target_type=target_type,
                    group_id=group_id,
                    user_id=user_id,
                )
                action = "预览"
        except ValueError as exc:
            return f"参数错误：{exc}"
        counts = result.get("deleted") if confirm == "清空" else result.get("counts")
        counts = counts or {}
        lines = [
            f"{action}范围：{self._clear_scope_label(target_type, group_id, user_id)}",
            "影响数量："
        ]
        for key in ["memories", "timeline", "relationship_edges", "knowledge_nodes", "knowledge_edges", "injection_logs", "summary_failures", "cross_window_threads"]:
            lines.append(f"- {key}: {counts.get(key, 0)}")
        if confirm != "清空":
            lines.append("确认执行请在命令末尾加：清空")
        elif result.get("backup"):
            lines.append(f"备份：{result.get('backup')}")
        return "\n".join(lines)

    @staticmethod
    def _clear_scope_label(target_type: str, group_id: str, user_id: str) -> str:
        if target_type == "group":
            return f"群聊 {group_id}"
        if target_type == "private":
            return f"私聊 {user_id}"
        return f"群聊 {group_id} 中的用户 {user_id}"

    async def visibility(self, memory_id: str = "", visibility: str = "") -> str:
        if not memory_id or not visibility:
            return "用法：/mcomp visibility <memory_id> private_pair|group_public|bot_self|shareable|internal"
        ok = await self.service.store.update_memory_visibility(memory_id, visibility)
        return f"已改为 {visibility}。" if ok else "没有找到这条记忆。"

    async def promote(self, memory_id: str = "") -> str:
        if not memory_id:
            return "用法：/mcomp promote <memory_id>"
        ok = await self.service.store.update_review_status(memory_id, "auto")
        return "已提升为稳定记忆。" if ok else "没有找到这条记忆。"

    async def archive(self, memory_id: str = "") -> str:
        if not memory_id:
            return "用法：/mcomp archive <memory_id>"
        ok = await self.service.store.update_memory_lifecycle(memory_id, "archived")
        return "已归档。" if ok else "没有找到这条记忆。"

    async def timeline(self, limit: int = 10) -> str:
        rows = await self.service.store.recent_timeline(limit)
        if not rows:
            return "还没有自我时间线事件。"
        lines = [f"最近自我时间线：{len(rows)} 条"]
        for row in rows:
            lines.append(
                f"- {row.get('occurred_at')}｜{row.get('event_type')}｜{row.get('scope')}｜{clean_text(row.get('content'), 160)}"
            )
        return "\n".join(lines)

    async def relations(self, limit: int = 20, entity_id: str = "") -> str:
        rows = await self.service.store.list_relationships(limit=limit, entity_id=entity_id)
        if not rows:
            return "还没有关系边。"
        lines = [f"关系边：{len(rows)} 条"]
        for row in rows:
            lines.append(
                f"- {row.get('subject_name') or row.get('subject_id')} --{row.get('relation_type')}--> "
                f"{row.get('object_name') or row.get('object_id')}｜{row.get('scope')}｜{clean_text(row.get('evidence'), 80)}"
            )
        return "\n".join(lines)

    async def threads(self, action: str = "list", thread_id: str = "") -> str:
        action = (action or "list").lower()
        if action in {"list", "ls"}:
            rows = await self.service.store.list_cross_window_threads(status="open", limit=20)
            if not rows:
                return "没有打开的跨窗口线程。"
            lines = [f"跨窗口线程：{len(rows)} 条"]
            for row in rows:
                lines.append(
                    f"- {row.get('id')}｜{row.get('from_session')} -> {row.get('to_session')}｜{row.get('topic')}｜{clean_text(row.get('content'), 120)}"
                )
            return "\n".join(lines)
        if action in {"close", "done"}:
            if not thread_id:
                return "用法：/mcomp threads close <thread_id>"
            ok = await self.service.store.update_cross_window_thread_status(thread_id, "closed")
            return "已关闭线程。" if ok else "没有找到这个线程。"
        return "用法：/mcomp threads list|close <thread_id>"

    async def logs(self, limit: int = 5) -> str:
        rows = await self.service.store.recent_injection_logs(limit)
        if not rows:
            return "还没有注入日志。"
        lines = [f"最近注入日志：{len(rows)} 条"]
        for row in rows:
            selected = row.get("selected_memory_ids") or []
            blocked = row.get("blocked_reasons") or []
            lines.append(
                f"- {row.get('created_at')}｜{row.get('scope')}｜选中 {len(selected)}｜过滤 {len(blocked)}｜chars={row.get('injection_chars')}｜{clean_text(row.get('query'), 100)}"
            )
        return "\n".join(lines)

    async def maintenance(self) -> str:
        state = await self.service.sleep_maintenance(reason="command_maintenance")
        result = state.get("repair", {})
        raw = state.get("raw_retention", {})
        decay = state.get("decay", {})
        wal = state.get("wal", {})
        return (
            "维护完成："
            f"可见性修正 {result.get('manual_visibility_fixed', 0)}，"
            f"原始话语修正 {result.get('utterance_reality_fixed', 0)}，"
            f"指纹补齐 {result.get('fingerprint_fixed', 0)}，"
            f"重复归档 {result.get('duplicates_archived', 0)}，"
            f"全文索引 {result.get('fts_rebuilt', 0)}；"
            f"原始事件归档 {raw.get('archived', 0)}；"
            f"衰减总结 {decay.get('summaries', 0)}，衰减归档 {decay.get('archived', 0)}；"
            f"WAL checkpoint busy={wal.get('checkpoint_busy', '-')} "
            f"frames={wal.get('checkpointed_frames', '-')}/{wal.get('checkpoint_log_frames', '-')}；"
            f"睡眠维护时间 {state.get('ran_at', '-')}"
        )

    async def audit(
        self,
        event: Any,
        action: str = "preview",
        batch_id: str = "",
        confirm: str = "",
        limit: int = 0,
    ) -> str:
        action = clean_text(action, 24).lower() or "preview"
        try:
            if action in {"preview", "check"}:
                result = await self.service.preview_memory_audit(event, limit)
            elif action == "status":
                if not clean_text(batch_id, 80):
                    return "用法：/mcomp audit status <batch_id>"
                result = await self.service.memory_audit_status(batch_id)
            elif action == "apply":
                if not clean_text(batch_id, 80):
                    return "用法：/mcomp audit apply <batch_id> 确认"
                result = await self.service.apply_memory_audit(batch_id, confirm)
            elif action == "rollback":
                if not clean_text(batch_id, 80):
                    return "用法：/mcomp audit rollback <batch_id> 确认"
                result = await self.service.rollback_memory_audit(batch_id, confirm)
            else:
                return self._audit_usage()
        except (ValueError, RuntimeError) as exc:
            return f"记忆审计未执行：{clean_text(exc, 300)}"
        return self._format_audit_result(result)

    @staticmethod
    def _format_audit_result(result: dict[str, Any]) -> str:
        items = result.get("items") if isinstance(result.get("items"), list) else []
        applied = result.get("applied_results") if isinstance(result.get("applied_results"), list) else []
        rolled_back = result.get("rollback_results") if isinstance(result.get("rollback_results"), list) else []
        lines = [
            f"记忆审计批次：{result.get('batch_id', '-')}",
            f"状态：{result.get('status', '-')}｜候选 {result.get('candidate_count', 0)}｜建议 {len(items)}",
        ]
        for item in items[:10]:
            lines.append(
                f"- {item.get('memory_id')}｜{item.get('action')}｜{clean_text(item.get('reason'), 120)}"
            )
        if applied:
            lines.append("应用结果：" + "，".join(f"{item.get('memory_id')}={item.get('status')}" for item in applied))
        if rolled_back:
            lines.append("回滚结果：" + "，".join(f"{item.get('memory_id')}={item.get('status')}" for item in rolled_back))
        if result.get("status") == "preview" and items:
            lines.append(f"确认应用：/mcomp audit apply {result.get('batch_id')} 确认")
        return "\n".join(lines)

    @staticmethod
    def _audit_usage() -> str:
        return (
            "/mcomp audit preview [数量]\n"
            "/mcomp audit status <batch_id>\n"
            "/mcomp audit apply <batch_id> 确认\n"
            "/mcomp audit rollback <batch_id> 确认"
        )

    async def diagnostics(self) -> str:
        report = await self.service.operational_report()
        cache = report.get("cache") or {}
        usage = report.get("model_usage") or {}
        retrieval = report.get("retrieval") or {}
        conflicts = report.get("conflicts") or []
        hit_rate = cache.get("hit_rate")
        hit_label = f"{float(hit_rate) * 100:.1f}%" if hit_rate is not None else "暂无样本"
        avg_ms = usage.get("average_elapsed_ms")
        avg_label = f"{float(avg_ms):.1f}ms" if avg_ms is not None else "暂无样本"
        lines = [
            "记忆运维诊断：",
            f"配置预设：{report.get('preset_label')} ({report.get('preset')})",
            f"检索：mode={retrieval.get('mode')}｜Embedding={retrieval.get('embedding_enabled')}｜零外部检索调用={retrieval.get('zero_external_retrieval_calls')}",
            f"缓存：命中 {cache.get('hits', 0)}｜未命中 {cache.get('misses', 0)}｜命中率 {hit_label}｜当前 {cache.get('entries', 0)} 项",
            f"模型消耗：调用 {usage.get('calls', 0)}｜已确认 Token {usage.get('reported_tokens', 0)}｜估算 Token {usage.get('estimated_tokens', 0)}｜合计 {usage.get('total_tokens', 0)}｜失败 {usage.get('errors', 0)}｜平均耗时 {avg_label}",
        ]
        if conflicts:
            lines.append("插件共存：")
            for item in conflicts:
                lines.append(
                    f"- {item.get('label')}｜{item.get('level')}｜{item.get('reason')}"
                )
        else:
            lines.append("插件共存：未检测到已知记忆插件目录。")
        warnings = report.get("warnings") or []
        if warnings:
            lines.append("注意：")
            lines.extend(f"- {warning}" for warning in warnings)
        lines.append(str(report.get("benchmark_note") or ""))
        return "\n".join(line for line in lines if line)

    def preset(self, action: str = "status", name: str = "") -> str:
        action = clean_text(action, 40).lower() or "status"
        name = clean_text(name, 40).lower()
        if action in {"light", "standard", "companion"} and not name:
            name = action
            action = "apply"
        if action in {"status", "show", "current"}:
            status = self.service.operation_preset_status()
            return (
                f"当前配置预设：{status.get('label')} ({status.get('preset')})\n"
                "可用：light（轻量）、standard（标准）、companion（陪伴）\n"
                "应用：/mcomp preset apply <名称>"
            )
        if action in {"apply", "use", "set"} and name in {"light", "standard", "companion"}:
            result = self.service.apply_operation_preset(name)
            return (
                f"已应用{result.get('label')}预设。\n"
                f"修改 {len(result.get('changed') or {})} 项；模型 Provider 选择保持不变。\n"
                f"配置：{result.get('config_path')}"
            )
        return "用法：/mcomp preset status|apply light|standard|companion"

    async def portable_data(self, action: str = "help", path: str = "") -> str:
        action = clean_text(action, 40).lower() or "help"
        path = str(path or "").strip()
        try:
            if action in {"export", "backup"}:
                result = await self.service.export_portable_data()
                counts = result.get("counts") or {}
                return (
                    "UTF-8 JSONL 导出完成：\n"
                    f"路径：{result.get('path')}\n"
                    f"记忆 {counts.get('memory', 0)}｜身份 {counts.get('identity', 0)}｜关系 {counts.get('relationship', 0)}｜"
                    f"时间线 {counts.get('timeline', 0)}｜ACL {counts.get('acl_rule', 0) + counts.get('acl_policy', 0)}"
                )
            if action in {"preview", "check"}:
                if not path:
                    return "用法：/mcomp data preview <jsonl_path>"
                result = self.service.preview_portable_data(path)
                return (
                    "可移植档案预览：\n"
                    f"路径：{result.get('path')}\n"
                    f"格式：{result.get('format')} v{result.get('version')}｜记录 {result.get('total_records', 0)}\n"
                    f"分类：{result.get('counts')}"
                )
            if action in {"import", "restore"}:
                if not path:
                    return "用法：/mcomp data import <jsonl_path>"
                result = await self.service.import_portable_data(path)
                return (
                    "可移植档案导入完成：\n"
                    f"导入：{result.get('imported')}\n"
                    f"跳过：{result.get('skipped')}\n"
                    f"导入前备份：{result.get('backup')}\n"
                    f"错误示例：{result.get('errors') or '无'}"
                )
        except (OSError, ValueError, RuntimeError) as exc:
            return f"数据操作失败：{exc}"
        return (
            "可移植数据命令：\n"
            "/mcomp data export\n"
            "/mcomp data preview <jsonl_path>\n"
            "/mcomp data import <jsonl_path>"
        )

    async def sleep(self, action: str = "status") -> str:
        action = (action or "status").lower()
        if action in {"run", "maintenance", "now"}:
            state = await self.service.sleep_maintenance(reason="command_sleep")
            repair = state.get("repair", {})
            raw = state.get("raw_retention", {})
            decay = state.get("decay", {})
            wal = state.get("wal", {})
            return (
                "睡眠维护完成："
                f"{state.get('ran_at', '-')}｜"
                f"指纹补齐 {repair.get('fingerprint_fixed', 0)}｜"
                f"重复归档 {repair.get('duplicates_archived', 0)}｜"
                f"全文索引 {repair.get('fts_rebuilt', 0)}｜"
                f"原始事件归档 {raw.get('archived', 0)}｜"
                f"衰减总结 {decay.get('summaries', 0)}｜"
                f"衰减归档 {decay.get('archived', 0)}｜"
                f"WAL {wal.get('checkpointed_frames', '-')}/{wal.get('checkpoint_log_frames', '-')}"
            )
        if action in {"status", "state", "last"}:
            state = self.service.sleep_status()
            return (
                "睡眠维护状态："
                f"{state.get('ran_at') or state.get('message') or '-'}"
            )
        return "用法：/mcomp sleep status|run"

    async def import_livingmemory(self, mode: str = "preview", path: str = "") -> str:
        configured = path or str(self.service.config.get("livingmemory_migration.livingmemory_db_path", "") or "")
        raw_mode = mode or "preview"
        mode = raw_mode.lower()
        known_modes = {
            "preview",
            "dry",
            "check",
            "detail",
            "details",
            "scan",
            "run",
            "import",
            "exec",
            "start",
            "help",
            "?",
            "usage",
        }
        if not path and mode not in known_modes:
            if raw_mode.endswith(".db") or "\\" in raw_mode or "/" in raw_mode:
                configured = raw_mode
                mode = "preview"
        if mode in {"help", "?", "usage"}:
            return self._livingmemory_usage()
        if mode in {"preview", "dry", "check"}:
            return self._format_livingmemory_preview(self.service.migrator.preview(configured))
        if mode in {"detail", "details", "scan"}:
            return self._format_livingmemory_preview(self.service.migrator.preview(configured), verbose=True)
        if mode in {"run", "import", "exec", "start"}:
            result = await self.service.import_livingmemory(configured_path=configured)
            return self._format_livingmemory_import_result(result)
        return self._livingmemory_usage()

    def help(self) -> str:
        return (
            "我会牢牢记住你命令：\n"
            "主入口 /mcomp。\n"
            "/mcomp status\n"
            "/mcomp search 关键词\n"
            "/mcomp explain 关键词\n"
            "/mcomp recent 10\n"
            "/mcomp add 要记住的内容\n"
            "/mcomp summarize\n"
            "/mcomp visibility <memory_id> <visibility>\n"
            "/mcomp promote <memory_id>\n"
            "/mcomp archive <memory_id>\n"
            "/mcomp timeline 10\n"
            "/mcomp relations [数量] [用户或群ID]\n"
            "/mcomp threads list|close <thread_id>\n"
            "/mcomp logs 5\n"
            "/mcomp maintenance\n"
            "/mcomp audit preview|status|apply|rollback\n"
            "/mcomp diagnostics\n"
            "/mcomp preset status|apply light|standard|companion\n"
            "/mcomp data export|preview|import [jsonl_path]\n"
            "/mcomp sleep status|run\n"
            "/mcomp delete <memory_id>\n"
            "/mcomp import_livingmemory preview|run|detail [db_path]"
        )

    def _format_livingmemory_preview(self, report: dict[str, Any], *, verbose: bool = False) -> str:
        if not report["candidates"]:
            return (
                "没找到 LivingMemory 数据库。\n"
                "可在配置页填写 livingmemory_db_path，或执行：\n"
                "/mcomp import_livingmemory preview <livingmemory.db>"
            )

        first = report["candidates"][0]
        if first.get("error"):
            return f"LivingMemory 读取失败：{first.get('error')}"

        importable_rows = sum(int(table.get("count") or 0) for table in first.get("tables", []) if table.get("importable"))
        skipped_rows = sum(int(table.get("count") or 0) for table in first.get("tables", []) if not table.get("importable"))
        lines = [
            "LivingMemory 预览：",
            f"将导入 {importable_rows} 条完整记忆，跳过 {skipped_rows} 条碎片。",
            f"来源：{first.get('path')}",
            "执行：/mcomp import_livingmemory run",
        ]
        if verbose:
            lines.insert(1, "策略：只导入 documents，跳过派生碎片。")
            lines.append("表：")
            for table in first.get("tables", [])[:10]:
                lines.append(f"- {self._format_livingmemory_table(table)}")
            if len(report["candidates"]) > 1:
                lines.append("其他候选：")
                for item in report["candidates"][1:5]:
                    summary = self._candidate_summary(item)
                    lines.append(f"- {item.get('path')}｜{summary}")
        else:
            lines.append("详情：/mcomp import_livingmemory detail")
        return "\n".join(lines)

    def _format_livingmemory_import_result(self, result: dict[str, Any]) -> str:
        if result.get("reason") and not result.get("source_path"):
            return (
                f"导入未执行：{result.get('reason')}\n"
                "先试：/mcomp import_livingmemory preview"
            )
        imported = int(result.get("imported") or 0)
        skipped = int(result.get("skipped") or 0)
        lines = [
            f"LivingMemory 导入完成：{imported} 条。",
            f"来源：{result.get('source_path') or '-'}",
        ]
        if skipped:
            lines.append(f"跳过异常行：{skipped} 条")
        if imported == 0:
            lines.append("没有新增内容，可能是旧库没有 documents 完整摘要。")
        elif result.get("fts_enabled"):
            lines.append(f"本地检索索引已重建：{int(result.get('fts_rebuilt') or 0)} 条。")
        else:
            lines.append("本地检索索引未启用，建议检查 SQLite FTS5 支持。")
        lines.append("可在记忆面板或 /mcomp search 中查看。")
        return "\n".join(lines)

    def _format_livingmemory_table(self, table: dict[str, Any]) -> str:
        name = table.get("name")
        count = table.get("count", 0)
        if table.get("importable"):
            return f"{name}｜{count} 行｜将导入完整记忆"
        return f"{name}｜{count} 行｜跳过：{self._livingmemory_note(table.get('note'))}"

    def _candidate_summary(self, item: dict[str, Any]) -> str:
        if item.get("error"):
            return f"读取失败：{item.get('error')}"
        importable_rows = sum(int(table.get("count") or 0) for table in item.get("tables", []) if table.get("importable"))
        skipped_rows = sum(int(table.get("count") or 0) for table in item.get("tables", []) if not table.get("importable"))
        return f"可导入 {importable_rows}，跳过 {skipped_rows}"

    def _livingmemory_note(self, note: Any) -> str:
        text = clean_text(note, 80)
        mapping = {
            "derived_fragment_not_imported": "派生事实碎片",
            "not_importable": "没有可导入正文",
        }
        return mapping.get(text, text or "不是完整记忆")

    def _livingmemory_usage(self) -> str:
        return (
            "LivingMemory 迁移：\n"
            "/mcomp import_livingmemory preview  预览\n"
            "/mcomp import_livingmemory run      导入\n"
            "/mcomp import_livingmemory detail   详情"
        )
