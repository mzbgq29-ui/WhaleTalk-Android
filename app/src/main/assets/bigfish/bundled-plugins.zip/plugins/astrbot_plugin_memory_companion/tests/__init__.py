"""MemoryCompanion regression tests."""
